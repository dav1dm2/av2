#produtos.py
import os

diretorio_atual = os.path.dirname(os.path.abspath(__file__))
caminho_produtos = os.path.join(diretorio_atual, 'data', 'produtos.txt')


# Função para criar a pasta de dados se não existir
def criar_pasta_dados():
    pasta_data = os.path.join(diretorio_atual, 'data')  # Caminho absoluto para a pasta 'data'
    
    # Verifica se a pasta 'data' existe; se não, cria
    if not os.path.exists(pasta_data):
        os.makedirs(pasta_data)
    
    # Verifica se o arquivo produtos.txt existe; se não, cria um arquivo vazio
    if not os.path.exists(caminho_produtos):
        open(caminho_produtos, 'w').close()


# Função para adicionar um produto
def adicionar_produto(nome, preco):
    with open(caminho_produtos, 'a') as file:
        file.write(f"{nome},{preco}\n")
    print(f"Produto '{nome}' adicionado com sucesso.")

# Função para listar produtos
def listar_produtos():
    try:
        with open(caminho_produtos, 'r') as file:
            produtos = file.readlines()
            if produtos:
                print("\nLista de Produtos:")
                for produto in produtos:
                    nome, preco = produto.strip().split(',')
                    print(f"Nome: {nome}, Preço: R$ {preco}")
            else:
                print("Nenhum produto cadastrado.")
    except FileNotFoundError:
        print("Nenhum produto cadastrado.")

# Função para remover um produto
def remover_produto(nome):
    try:
        with open(caminho_produtos, 'r') as file:
            produtos = file.readlines()

        with open(caminho_produtos, 'w') as file:
            produto_encontrado = False
            for produto in produtos:
                if produto.split(',')[0] != nome:
                    file.write(produto)
                else:
                    produto_encontrado = True

        if produto_encontrado:
            print(f"Produto '{nome}' removido com sucesso.")
        else:
            print(f"Produto '{nome}' não encontrado.")
    except FileNotFoundError:
        print("Nenhum produto cadastrado.")
