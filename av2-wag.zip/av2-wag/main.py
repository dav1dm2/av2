# main.py

from usuarios import cadastrar_usuario, autenticar_usuario, is_admin
from produtos import adicionar_produto, listar_produtos, remover_produto


def menu_usuarios():
    while True:
        print("\nMenu de Usuários:")
        print("1. Login")
        print("2. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            nome_usuario = input("Digite o nome do usuário: ")
            senha = input("Digite a senha: ")
            if autenticar_usuario(nome_usuario, senha):
                print("Login bem-sucedido.")
                if is_admin(nome_usuario):
                    menu_admin()  # Menu especial para o administrador
                else:
                    menu_produtos()  # Menu normal para os usuários
            else:
                print("Usuário ou senha inválidos.")
        elif opcao == "2":
            break
        else:
            print("Opção inválida.")

def menu_admin():
    while True:
        print("\nMenu de Administração:")
        print("1. Cadastrar Usuário")
        print("2. Gerenciar Produtos")
        print("3. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            nome_usuario = input("Digite o nome do novo usuário: ")
            senha = input("Digite a senha: ")
            cadastrar_usuario(nome_usuario, senha)
            print(f"Usuário '{nome_usuario}' cadastrado com sucesso.")
        elif opcao == "2":
            menu_produtos()  # Permite ao administrador gerenciar os produtos
        elif opcao == "3":
            break
        else:
            print("Opção inválida.")

def menu_produtos():
    while True:
        print("\nMenu de Produtos:")
        print("1. Adicionar Produto")
        print("2. Listar Produtos")
        print("3. Remover Produto")
        print("4. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            nome = input("Nome do produto: ")
            preco = float(input("Preço do produto: "))
            adicionar_produto(nome, preco)
        elif opcao == "2":
            listar_produtos()
        elif opcao == "3":
            nome = input("Nome do produto a ser removido: ")
            remover_produto(nome)
        elif opcao == "4":
            break
        else:
            print("Opção inválida.")

if __name__ == "__main__":
    menu_usuarios()
