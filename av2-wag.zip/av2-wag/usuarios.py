# usuarios.py
import os

diretorio_atual = os.path.dirname(os.path.abspath(__file__))
caminho_usuarios = os.path.join(diretorio_atual, 'data', 'usuarios.txt')


def criar_pasta_dados():
    pasta_data = os.path.join(diretorio_atual, 'data')  # Caminho absoluto para a pasta 'data'
    
    # Verifica se a pasta 'data' existe; se não, cria
    if not os.path.exists(pasta_data):
        os.makedirs(pasta_data)
    
    # Verifica se o arquivo produtos.txt existe; se não, cria um arquivo vazio
    if not os.path.exists(caminho_usuarios):
        with open(caminho_usuarios, 'w') as file:
            # Adiciona um administrador padrão
            file.write("admin,admin123\n")  # Usuário: admin, Senha: admin123


def cadastrar_usuario(nome_usuario, senha):
    criar_pasta_dados()

    # Abre o arquivo usuarios.txt em modo append
    with open(caminho_usuarios, 'a') as file:
        file.write(f"{nome_usuario},{senha}\n")  # Armazena o nome e a senha separados por vírgula


def autenticar_usuario(nome_usuario, senha):
    try:
        criar_pasta_dados()

        # Abre o arquivo usuarios.txt em modo leitura
        with open(caminho_usuarios, 'r') as file:
            for linha in file:
                usuario, senha_armazenada = linha.strip().split(',')  # Divide a linha em nome e senha
                if usuario == nome_usuario and senha_armazenada == senha:
                    return True  # Retorna True se o usuário for encontrado
    except FileNotFoundError:
        print("Arquivo de usuários não encontrado.")
    return False  # Retorna False se não encontrar o usuário

def is_admin(nome_usuario):
    return nome_usuario == "admin"  # Verifica se o nome do usuário é "admin"